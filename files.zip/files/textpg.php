/Users/parag/Fourlance/Projects/Saipooja/Edit/2019/Aug/12/Prebkp/

<input type="text"  onkeypress="return (event.charCode >= 48 ||  event.charCode <= 57) || event.charCode == 65 || event.charCode ==66">


<?php
$a=0;

$a=1;
is_int($a);
if(is_int($a))
echo "Hello";

?>