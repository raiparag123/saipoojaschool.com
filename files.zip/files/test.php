<?php
ob_start();
require 'db.php'; 
// session_start();
// if(!isset($_SESSION["loginid"])){
// 	header('Location:login.php');	
// }
?>
<?php
$stmt = $mysqli->prepare("SELECT class_subject_id,subject_id,class_id,fy_id,status from class_subject_master");
$result = $stmt->execute();
$stmt->store_result();
$stmt->bind_result($class_subject_id,$subject_id,$class_id,$fy_id,$status);
$count=$stmt->num_rows;
while($data = $stmt->fetch()) {
echo "insert into class_subject_master   (class_subject_id,subject_id,class_id,fy_id,status) values ('".$class_subject_id."','".$subject_id."','".$class_id."','".$fy_id."','".$status."');<br>";
}
?>


